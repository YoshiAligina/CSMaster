package com.example.atari3;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings("ALL")
public class MainActivity extends AppCompatActivity {


    GameSurface gameSurface;
    MediaPlayer mp;
    boolean g = true;
    private SoundPool sp;
    int crash;
    AtomicInteger time = new AtomicInteger(30);
    int score = 0;
    AtomicInteger diff = new AtomicInteger(5);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameSurface = new GameSurface(this);
        setContentView(gameSurface);
        MyCount timerCount = new MyCount(30 * 1000, 1000);
        timerCount.start();



        mp = MediaPlayer.create(this,R.raw.lvjy);
        if (mp.isPlaying()) {
            mp.stop();
            try {
                mp.prepare();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        else
            mp.start();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes
                    audioAttributes
                    = new AudioAttributes
                    .Builder()
                    .setUsage(
                            AudioAttributes
                                    .USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(
                            AudioAttributes
                                    .CONTENT_TYPE_SONIFICATION)
                    .build();
            sp  = new SoundPool
                    .Builder()
                    .setMaxStreams(3)
                    .setAudioAttributes(
                            audioAttributes)
                    .build();
        }
        else {
            sp
                    = new SoundPool(
                    3,
                    AudioManager.STREAM_MUSIC,
                    0);
        } //SOUNDPOOL BUILDER FROM GEEEKSFORGEEKS
        crash = sp.load(this, R.raw.crash, 1);

    }


    @Override
    protected void onPause() {
        super.onPause();
        gameSurface.pause();
        mp.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameSurface.resume();
        mp = MediaPlayer.create(this,R.raw.lvjy);
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        mp.reset();
        mp.release();
        mp = null;
    }
    public class MyCount extends CountDownTimer {
        public MyCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onFinish() {
            g = false;
        }

        @Override
        public void onTick(long millisUntilFinished) {
            //I learnt the timer from Stack Overflow
        }
    }


    // ----------------------------GameSurface Below This Line--------------------------
    public class GameSurface extends SurfaceView implements Runnable, SensorEventListener {

        Thread gameThread;
        SurfaceHolder holder;
        volatile boolean running = false;
        Bitmap car, carsad, man, endchar, gameover, road;
        float carx = 0;
        int opponentY =0;
        int xy = 200;

        Paint paintProperty;
        int screenWidth, screenHeight;
        float x, pl, pt, ot, nyoom;
        float ol = (float) (Math.random()* screenWidth);

        boolean ouch = false;

        boolean touch = false;
        boolean orange = true;


        public GameSurface(Context context) {
            super(context);
            holder = getHolder();
            car = BitmapFactory.decodeResource(getResources(), R.drawable.car);
          //  road = BitmapFactory.decodeResource(getResources(), R.drawable.road);
            carsad = BitmapFactory.decodeResource(getResources(), R.drawable.carsad);
            man = BitmapFactory.decodeResource(getResources(), R.drawable.mansmall);
             endchar = BitmapFactory.decodeResource(getResources(), R.drawable.endchar);
             gameover = BitmapFactory.decodeResource(getResources(), R.drawable.gameover);



            Display screenDisplay = getWindowManager().getDefaultDisplay();
            Point sizeOfScreen = new Point();
            screenDisplay.getSize(sizeOfScreen);
            screenWidth = sizeOfScreen.x;
            screenHeight = sizeOfScreen.y;

            SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            Sensor accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            sensorManager.registerListener(this, accel, sensorManager.SENSOR_DELAY_NORMAL);

            paintProperty = new Paint();
            paintProperty.setTextSize(100);
            paintProperty.setColor(Color.WHITE);

        }

        @Override
        public void run() {
            int soup = 1;
            while (running == true) {
                if (holder.getSurface().isValid() == false)
                    continue;
                Canvas canvas = holder.lockCanvas();

                //canvas.drawBitmap(road,0,0, null);
               canvas.drawRGB(194, 178, 128);
                if(ouch)
                {
                    canvas.drawBitmap(carsad, (screenWidth / 2) - car.getWidth() / 2 + carx, (screenHeight - 250) - car.getHeight(), null);
                }
                else
                {
                    canvas.drawBitmap(car, (screenWidth / 2) - car.getWidth() / 2 + carx, (screenHeight - 250) - car.getHeight(), null);
                }
                if (g)
                {
                    pl = (screenWidth/2)-(car.getWidth()/2)+carx;
                    pt = 500;
                    if (touch)
                    {

                    }
                    if(!ouch) {
                        canvas.drawBitmap(man, ol, opponentY, null);
                    }

                   opponentY += 8;

                   if(opponentY > screenHeight)
                   {
                       opponentY = 0;
                       ol = (float) (Math.random()* screenWidth);

                       if(orange){
                           score += 1;
                       }
                       else
                       {
                           orange = true;
                       }
                       Log.d("ORANGE",orange+" "+score);
                   }
                    if (x > 0)
                        soup = -1;
                    else
                        soup = 1;

                    double rightmost = screenWidth / 2 - car.getWidth() / 2;
                    double leftmost =  screenWidth / 2 + car.getWidth() / 2;
                    if (carx <= rightmost)
                    {
                        soup = 1;

                        if (x > 0)
                            nyoom = 0;
                    } else if (carx >= leftmost)
                    {
                        soup = -1;

                        if (x < 0)
                            nyoom = 0;
                    }

                 Rect p = new Rect((int) ((screenWidth / 2) - car.getWidth() / 3 + carx)+40, (screenHeight - 250) - car.getHeight()+35, car.getWidth()+(int)pl-150 ,(screenHeight-250)-55);
                    Rect o = new Rect((int)ol+90, opponentY-20,man.getWidth()+(int)ol-60 ,man.getHeight()+opponentY-30);

                   // canvas.drawRect(p, new Paint());
                 //   canvas.drawRect(o, new Paint());


                    if (Rect.intersects(p, o) || Rect.intersects(o, p)) {
                        ouch = true;
                        Log.d("COLLIDE",ouch+" ");
                        orange = false;
                        sp.play(crash, 1, 1, 1, 0, 1);
                    }
                    else
                    {
                        ouch = false;
                    }

                  //  carx += soup * nyoom;
                    canvas.drawText("Score: " + score, 300, 100, paintProperty);
                }
                else
                {
                   canvas.drawBitmap(gameover, 0, 0,null);
                  canvas.drawBitmap(endchar,  -50, 400, null);
                    canvas.drawText("Score: " + score, 300, 100, paintProperty);
                    canvas.drawText("GAME OVER", 500, 500, paintProperty);
                }

                holder.unlockCanvasAndPost(canvas);
            }
        }
        public void resume() {
            running = true;
            gameThread = new Thread(this);
            gameThread.start();
        }
        public void pause() {
            running = false;
            while (true) {
                try {
                    gameThread.join();
                } catch (InterruptedException e) {
                }
            }
        }
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if(!ouch) {


                x = sensorEvent.values[0];
                Log.d("SNESOR", x + " ");

                carx = x * 27;
            }

        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
        @Override
        public boolean onTouchEvent(MotionEvent motionEvent)
        {
            Log.d("on touch event", "running");
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            {
                switch (Integer.parseInt(String.valueOf(diff))) {
                    case 30:
                        diff.set(5);
                        break;
                    case 5:
                        diff.set(15);
                        break;
                    case 15:
                        diff.set(30);
                        break;
                }
                float x = motionEvent.getX();
                float y = motionEvent.getY();
                if( x > pl + car.getWidth() * 5 / 16 && x < pl + car.getWidth() * 4 / 6 && y > pt + car.getHeight() / 4 && y < pt + car.getHeight() * 5 / 8 )
                {
                    touch = true;
                }
            }
            return true;
        }
    }
};